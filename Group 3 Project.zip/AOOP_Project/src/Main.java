public class Main{
    MainFrame mainFrame;

    public Main() {
    this.mainFrame = new MainFrame();
    }

    public static void main(String[] args) throws Exception {
        new Main();
    }
}
